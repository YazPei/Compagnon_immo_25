from dagshub.data_engine import datasources
ds= datasources.create_datasource('YazPei/Compagnon_immo', 'my-datasource', 'data')
